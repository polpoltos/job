import requests
import json
import time
import openpyxl

url_cmt = 'https://fort.centr-tmt.ru'


def connect_to_api():
    """Функция подключения к API"""
    url = f"{url_cmt}/api/integration/v1/connect"
    params = {
        "login": "engineer145",
        "password": "engineer145",
        "lang": "ru-ru",
        "timezone": "3"
    }

    response = requests.get(url, params=params)

    if response.status_code == 200:
        print("Авторизация успешна!")
        return response.cookies
    else:
        print(f"Ошибка авторизации: {response.status_code}")
        return None


def get_sensors(remote_id, cookies):
    """Функция получения сенсоров с использованием cookies от подключения"""
    time.sleep(1)
    url = f"{url_cmt}/api/integration/v1/objsensorslist"
    params = {"oid": f"{remote_id}"}

    response = requests.get(url, params=params, cookies=cookies)

    if response.status_code == 200:
        print("Данные сенсоров получены!")
        return response.json()
    else:
        print(f"Ошибка получения сенсоров: {response.status_code}")
        return None


def mapping(remote_id, name):
    time.sleep(1)
    url = "http://93.90.221.111:4292/v1/responseParameter"

    # ИСПРАВЛЕННЫЕ HEADERS - text/plain вместо application/json
    headers = {
        'accept': '*/*',
        'Content-Type': 'text/plain; charset=utf-8'  # ← ВАЖНО!
    }

    # Формируем данные как plain text
    data = f'{{"domain": "{url_cmt}", "type": 0, "object_remote_id": "{remote_id}", "value": "{name}"}}'

    try:
        response = requests.post(
            url,
            headers=headers,
            data=data.encode('utf-8'),  # Явно кодируем в bytes
            timeout=30
        )

        print(f"Статус код: {response.status_code}")
        print(f"Ответ: {response.text}")

        if response.status_code == 200:
            print("✅ Запрос выполнен успешно!")
        else:
            print(f"❌ Ошибка: {response.status_code}")

    except requests.exceptions.RequestException as e:
        print(f"❌ Ошибка при выполнении запроса: {e}")


def read_excel(file_path):
    # Открываем файл Excel
    workbook = openpyxl.load_workbook(file_path)
    sheet = workbook.active
    cookies = connect_to_api()
    if cookies:
        for row in sheet.iter_rows(min_row=2, values_only=True):
            remote_id = str(row[0])
            print(remote_id)
            sensors_data = get_sensors(remote_id, cookies)
            if sensors_data and 'obj_sensors' in sensors_data:
                fuels = []
                for sensor in sensors_data['obj_sensors']:
                    if sensor.get('icon') == 'fuel.png':
                        fuels.append(sensor.get('name', ''))

                if fuels:
                    fuel_name = fuels[-1]
                    print(f"Отправляем значение: '{fuel_name}'")
                    mapping(remote_id, fuel_name)
                else:
                    print("Не найдено сенсоров с иконкой fuel.png")
            else:
                print("Не удалось получить данные сенсоров")



read_excel('New.xlsx')